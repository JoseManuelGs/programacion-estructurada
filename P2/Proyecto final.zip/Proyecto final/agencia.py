import os
import time
import pyfiglet
from tqdm import tqdm

vehiculo = {
    "urbanos": [
        {
            "marca": "Nissan",
            "modelo": "Leaf",
            "año": 2021,
            "potencia": "147 HP",
            "transmision": "Automática",
            "motor": "Motor Eléctrico de 110 kW",
            "neumaticos": "205/55 R16",
            "rines": "Aleación 16''",
            "tipo_combustible": "Eléctrico",
            "precio": 750000
        },
        {
            "marca": "Chevrolet",
            "modelo": "Spark",
            "año": 2020,
            "potencia": "98 HP",
            "transmision": "Manual",
            "motor": "1.4L 4 cilindros",
            "neumaticos": "155/70 R13",
            "rines": "Acero 13''",
            "tipo_combustible": "Gasolina",
            "precio": 180000
        },
        {
            "marca": "Kia",
            "modelo": "Picanto",
            "año": 2022,
            "potencia": "84 HP",
            "transmision": "Automática",
            "motor": "1.2L 4 cilindros",
            "neumaticos": "175/65 R14",
            "rines": "Aleación 14''",
            "tipo_combustible": "Gasolina",
            "precio": 210000
        },
        {
            "marca": "Hyundai",
            "modelo": "Kona Electric",
            "año": 2023,
            "potencia": "201 HP",
            "transmision": "Automática",
            "motor": "Motor Eléctrico de 150 kW",
            "neumaticos": "215/55 R17",
            "rines": "Aleación 17''",
            "tipo_combustible": "Eléctrico",
            "precio": 800000
        }
    ],
   "familiares": [
        {
            "marca": "Toyota",
            "modelo": "Avanza",
            "año": 2021,
            "potencia": "103 HP",
            "transmision": "Automática",
            "motor": "1.5L 4 cilindros",
            "neumaticos": "185/65 R15",
            "rines": "Aleación 15''",
            "tipo_combustible": "Gasolina",
            "precio": 330000
        },
        {
            "marca": "Honda",
            "modelo": "BR-V",
            "año": 2022,
            "potencia": "121 HP",
            "transmision": "CVT",
            "motor": "1.5L 4 cilindros",
            "neumaticos": "195/60 R16",
            "rines": "Aleación 16''",
            "tipo_combustible": "Gasolina",
            "precio": 350000
        },
        {
            "marca": "Chevrolet",
            "modelo": "Captiva",
            "año": 2023,
            "potencia": "144 HP",
            "transmision": "Automática",
            "motor": "1.5L Turbo",
            "neumaticos": "215/60 R17",
            "rines": "Aleación 17''",
            "tipo_combustible": "Gasolina",
            "precio": 400000
        }
    ],
    "deportivos": [
        {
            "marca": "Tesla",
            "modelo": "Roadster",
            "año": 2023,
            "potencia": "1100 HP",
            "transmision": "Automática",
            "motor": "Triple Motor Eléctrico",
            "neumaticos": "295/35 R21",
            "rines": "Aleación 21''",
            "tipo_combustible": "Eléctrico",
            "precio": 4300000
        },
        {
            "marca": "Chevrolet",
            "modelo": "Camaro",
            "año": 2021,
            "potencia": "455 HP",
            "transmision": "Automática",
            "motor": "6.2L V8",
            "neumaticos": "245/40 R20",
            "rines": "Aleación 20''",
            "tipo_combustible": "Gasolina",
            "precio": 900000
        },
        {
            "marca": "Nissan",
            "modelo": "370Z",
            "año": 2020,
            "potencia": "332 HP",
            "transmision": "Manual",
            "motor": "3.7L V6",
            "neumaticos": "245/40 R19",
            "rines": "Aleación 19''",
            "tipo_combustible": "Gasolina",
            "precio": 750000
        }
    ]
}
ventas_totales = 0  # 💵 Acumulador global para ventas

def escribir(texto, velocidad=0.02):
    for caracter in texto:
        print(caracter, end='', flush=True)
        time.sleep(velocidad)
    print()

def borrar_pantalla():
    os.system('cls' if os.name == 'nt' else 'clear')

def barra_progreso(segundos=1.5):
    for _ in tqdm(range(1, 101), ncols=70, bar_format='{l_bar}{bar}'):
        time.sleep(segundos / 100)

def esperartecla():
    input("\nPulsa ENTER para continuar...")

def mostrar_menu():
    borrar_pantalla()
    barra_progreso()
    titulo = pyfiglet.figlet_format("AGENCIA DE AUTOS", font="slant")
    print(titulo)
    escribir("1. Agregar vehículo 📝", 0.01)
    escribir("2. Vender vehículo ✅", 0.01)
    escribir("3. Eliminar vehículo 📛", 0.01)
    escribir("4. Cambiar características 🔄", 0.01)
    escribir("5. Buscar por categoría 🔍", 0.01)
    escribir("6. Ver catálogo completo 📂", 0.01)
    escribir("7. Ventas totales 💰", 0.01)
    escribir("8. Salir 🚪", 0.01)
  

def agregar_vehiculo():
    borrar_pantalla()
    barra_progreso()
    borrar_pantalla()
    escribir("AGREGAR VEHÍCULO 📝\n", 0.02)
    categorias = list(vehiculo.keys())
    for i, cat in enumerate(categorias, 1):
        print(f"{i}. {cat.capitalize()}")
    seleccion = input("Selecciona una categoría por número: ").strip()
    if not seleccion.isdigit() or int(seleccion) < 1 or int(seleccion) > len(categorias):
        escribir("❌ Opción inválida. Vehículo no agregado.", 0.02)
        return
    categoria = categorias[int(seleccion) - 1]
    marca = input("Marca: ").strip()
    modelo = input("Modelo: ").strip()
    try: año = int(input("Año: ").strip())
    except: año = 0
    potencia = input("Potencia: ").strip()
    transmision = input("Transmisión: ").strip()
    motor = input("Motor: ").strip()
    neumaticos = input("Neumáticos: ").strip()
    rines = input("Rines: ").strip()
    tipo_combustible = input("Combustible: ").strip().capitalize()
    try: precio = int(input("Precio: ").strip())
    except: precio = 0
    nuevo = {"marca": marca, "modelo": modelo, "año": año, "potencia": potencia,
             "transmision": transmision, "motor": motor, "neumaticos": neumaticos,
             "rines": rines, "tipo_combustible": tipo_combustible, "precio": precio}
    vehiculo[categoria].append(nuevo)
    escribir("\n✅ Vehículo agregado exitosamente 🚗", 0.02)
    esperartecla()

def vender_vehiculo():
    global ventas_totales
    borrar_pantalla()
    barra_progreso()
    borrar_pantalla()
    escribir("VENDER VEHÍCULO ✅\n", 0.02)

    # Mostrar todos los vehículos disponibles
    escribir("🚗 Vehículos disponibles:\n", 0.01)
    for categoria in vehiculo:
        escribir(f"\n📂 Categoría: {categoria.upper()}", 0.01)
        for auto in vehiculo[categoria]:
            print("-" * 40)
            escribir(f"Marca: {auto['marca']}", 0.005)
            escribir(f"Modelo: {auto['modelo']}", 0.005)
            escribir(f"Año: {auto['año']}", 0.005)
            escribir(f"Precio: ${auto['precio']}", 0.005)

    modelo_buscado = input("\n📝 Ingresa el modelo a vender: ").strip().lower()

    for categoria in vehiculo:
        for i, auto in enumerate(vehiculo[categoria]):
            if auto["modelo"].lower() == modelo_buscado:
                escribir(f"\n✅ Vendido {auto['marca']} {auto['modelo']} por ${auto['precio']}", 0.02)
                ventas_totales += auto["precio"]
                del vehiculo[categoria][i]
                esperartecla()
                return

    escribir("❌ Vehículo no encontrado.", 0.02)
    esperartecla()

def eliminar_vehiculo():
    borrar_pantalla()
    barra_progreso()
    borrar_pantalla()
    escribir("ELIMINAR VEHÍCULO 📛\n", 0.02)

    lista_autos = []
    for categoria in vehiculo:
        for auto in vehiculo[categoria]:
            lista_autos.append((categoria, auto))

    if not lista_autos:
        escribir("⚠️ No hay vehículos para eliminar.", 0.02)
        esperartecla()
        return

    for idx, (cat, auto) in enumerate(lista_autos, 1):
        print(f"{idx}. [{cat.capitalize()}] {auto['marca']} {auto['modelo']}")

    seleccion = input("\nSelecciona el número del vehículo a eliminar: ").strip()
    if not seleccion.isdigit() or int(seleccion) < 1 or int(seleccion) > len(lista_autos):
        escribir("❌ Selección inválida.", 0.02)
        esperartecla()
        return

    idx = int(seleccion) - 1
    cat, auto = lista_autos[idx]
    vehiculo[cat].remove(auto)
    escribir(f"📛 Vehículo {auto['marca']} {auto['modelo']} eliminado correctamente.", 0.02)
    esperartecla()

def cambiar_caracteristicas():
    borrar_pantalla()
    barra_progreso()
    borrar_pantalla()
    escribir("CAMBIAR CARACTERÍSTICAS 🔄\n", 0.02)
    categorias = list(vehiculo.keys())
    for i, cat in enumerate(categorias, 1):
        print(f"{i}. {cat.capitalize()}")
    seleccion = input("Selecciona categoría: ").strip()
    if not seleccion.isdigit() or int(seleccion) < 1 or int(seleccion) > len(categorias):
        escribir("❌ Opción inválida.", 0.02)
        return
    categoria = categorias[int(seleccion) - 1]
    campo = input("Característica a modificar: ").strip().lower()
    for auto in vehiculo[categoria]:
        if campo in auto:
            escribir(f"Modelo: {auto['modelo']} - Actual: {auto[campo]}", 0.01)
            nuevo = input(f"Nuevo valor para {campo}: ").strip()
            auto[campo] = int(nuevo) if campo in ["precio", "año"] and nuevo.isdigit() else nuevo
    escribir("🔄 Característica actualizada.", 0.02)
    esperartecla()

def buscar_categoria():
    borrar_pantalla()
    barra_progreso()
    borrar_pantalla()
    escribir("BUSCAR POR CATEGORÍA 🔍\n", 0.02)
    categorias = list(vehiculo.keys())
    for i, cat in enumerate(categorias, 1):
        print(f"{i}. {cat.capitalize()}")
    seleccion = input("Selecciona categoría: ").strip()
    if not seleccion.isdigit() or int(seleccion) < 1 or int(seleccion) > len(categorias):
        escribir("❌ Categoría inválida.", 0.02)
        esperartecla()
        return
    categoria = categorias[int(seleccion) - 1]
    borrar_pantalla()
    for auto in vehiculo[categoria]:
        print("-"*30)
        for clave, valor in auto.items():
            print(f"{clave.capitalize()}: {valor}")
    esperartecla()

def mostrar_catalogo():
    borrar_pantalla()
    barra_progreso()
    borrar_pantalla()
    escribir("CATÁLOGO DE VEHÍCULOS 📂\n", 0.02)
    for categoria in vehiculo:
        escribir(f"\nCategoría: {categoria.upper()}", 0.01)
        for auto in vehiculo[categoria]:
            print("-" * 30)
            for clave, valor in auto.items():
                escribir(f"{clave.capitalize()}: {valor}", 0.005)
    esperartecla()

def mostrar_ventas_totales():
    borrar_pantalla()
    barra_progreso()
    borrar_pantalla()
    escribir("VENTAS TOTALES 💰\n", 0.02)
    escribir(f"Total vendido: ${ventas_totales} 🎉", 0.02)
    esperartecla()