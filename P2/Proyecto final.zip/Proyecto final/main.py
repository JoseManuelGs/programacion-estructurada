import agencia

def main():
    continua = True
    while continua:
        agencia.mostrar_menu()
        opcion = input("\nElige una opción (1-8): ").strip()

        match opcion:
            case "1":
                agencia.agregar_vehiculo()
            case "2":
                agencia.vender_vehiculo()
            case "3":
                agencia.eliminar_vehiculo()
            case "4":
                agencia.cambiar_caracteristicas()
            case "5":
                agencia.buscar_categoria()
            case "6":
                agencia.mostrar_catalogo()
            case "7":
                agencia.mostrar_ventas_totales()
            case "8":
                print("Gracias por usar la agencia de autos. ¡Hasta pronto! 🚪")
                continua = False
            case _:
                print("Opción inválida. ❌")
                agencia.esperartecla()

if __name__ == "__main__":
    main()
